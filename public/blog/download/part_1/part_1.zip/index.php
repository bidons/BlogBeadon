
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.1/js/jquery.dataTables.min.js"></script>

<div class="row">
	<table id="example" class="display" cellspacing="0" width="100%">
		<thead>
		<tr>
			<th>id</th>
			<th>v1</th>
			<th>v2</th>
		</tr>
		</thead>
	</table>
</div>

<script>
	var table = 'test_p1';
	$('#example').DataTable({
		"processing": true,
		"serverSide": true,
		"searching":false,
		"dom": 'C<"clear">lfrtip',
		"ajax": {
			"url": "field.php",
			type: "GET",
			"data": function (d) {
				d.objdb = table;
			}
		},
		"columns":[{"data":"id"},
			{"data":"v1"},
			{"data":"v2"}]
	});
</script>