DROP FUNCTION IF EXISTS paging_objectdb_part_1( JSONB );
DROP TABLE IF EXISTS test_p1;

CREATE TABLE test_p1 AS
  (
    SELECT
      generate_series(1, 100000) AS id,
      md5(random() :: TEXT)      AS v1,
      md5(random() :: TEXT)      AS v2
  );

CREATE OR REPLACE FUNCTION public.paging_objectdb_part_1(a_js jsonb)
  RETURNS SETOF jsonb
AS
$BODY$
  DECLARE
  val_draw    TEXT = $1 ->> 'draw'; -- Draw counter
  val_table   TEXT = $1 ->> 'objdb'; -- DB obj name
  val_offlim  TEXT = concat_ws(' ',
                               'limit ', $1 ->> 'length',
                               'offset', $1 ->> 'start'); -- Limit Offset ;

  val_order   JSONB = jsonb_array_elements($1 -> 'order'); -- Get order params from json

  val_orderby TEXT = concat_ws(' ',
                               'order by',
                               ((val_order ->> 'column') :: INTEGER + 1) :: TEXT,
                               val_order ->> 'dir'); -- Order by condition

  val_data text;
  val_filtered text;
  val_total text;
BEGIN

  -- Create query: pagination by condition
  SELECT concat_ws(' ', 'WITH objdb AS
                          (','SELECT * ', '
                              FROM', val_table,val_orderby, val_offlim, ')',
                          'SELECT ', 'json_agg(row_to_json(objdb))
                           FROM objdb')
  INTO val_data;

  -- Query: count by condition
  SELECT concat_ws(' ', 'SELECT count(*)',
                   'FROM', val_table)
  INTO val_filtered;

  -- Query: total count

  SELECT concat_ws(' ', 'SELECT count(*)',
                        'FROM', val_table)
  INTO val_total;


  -- Execute query
  EXECUTE val_data
  INTO val_data;

  -- Execute query
  EXECUTE val_total
  INTO val_total;

  -- Execute query
  EXECUTE val_filtered
  INTO val_filtered;

  -- Json result for datatable
  RETURN QUERY
  SELECT jsonb_build_object('draw', val_draw,
                            'recordsTotal', val_total,
                            'recordsFiltered', val_filtered,'data',coalesce(val_data, '[]') :: JSONB);
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

